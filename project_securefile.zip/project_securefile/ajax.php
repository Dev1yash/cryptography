<?php

    include 'functions.php';

    if(isset($_POST['user_id']) && isset($_POST['file_id']))
    {
        $user_id = $_POST['user_id'];
        $file_id = $_POST['file_id'];
        $result = insertFileRequest($user_id,$file_id);
        echo $result;
    }

    if(isset($_POST['filesbtkey']))
    {
        $fileKey = $_POST['filesbtkey'];
        $result = createDownloadLink($fileKey);
        echo $result['filePath'];
    }

?>