<?php
    include 'functions.php';
    getHeader();
    if(!checkAdminSession())
    {
        ?>
            <script>location.href='index.php';</script>
        <?php
    }
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
    function getFileData(fileid)
    {
        $.post(
            'ajax.php',
            'fileid='+fileid,
            function(response)
            {
                response = JSON.parse(response);
                var fileType = response.fileType;
                var filePath = response.filePath;
                if(fileType =='jpg' || fileType == 'png' || fileType == 'jpeg' || fileType == 'gif')
                {
                    var imgSrc = filePath; 
                    imgSrc = imgSrc.replace(/\\/g, '');
                    var imgAlt = "View Decrypted Image"; 
                    var img = $('<img>').attr('src', imgSrc).attr('alt', imgAlt).attr('width', '100%');
                    var downloadBtn = $('<a>').attr('href', imgSrc).attr('download', imgAlt + '.jpg').text('Download');
                    $('#modalBody').empty().append(img).append(downloadBtn);
                }
                if(fileType == 'txt')
                {
                    var imgSrc = '../assets/img/text-file.png'; 
                    imgSrc = imgSrc.replace(/\\/g, '');
                    var imgAlt = "View Decrypted Text File"; 
                    var img = $('<img>').attr('src', imgSrc).attr('alt', imgAlt).attr('width', '100%').css('width','250px').css('height','250px').css('margin','auto').css('display','block');
                    var downloadBtn = $('<a>').attr('href', filePath).attr('download', imgAlt + '.txt').text('Download');
                    $('#modalBody').empty().append(img).append(downloadBtn);
                }
                if(fileType == 'doc' || fileType == 'docx')
                {
                    var imgSrc = '../assets/img/doc-file.png'; 
                    imgSrc = imgSrc.replace(/\\/g, '');
                    var imgAlt = "View Decrypted Doc File"; 
                    var img = $('<img>').attr('src', imgSrc).attr('alt', imgAlt).attr('width', '100%').css('width','250px').css('height','250px').css('margin','auto').css('display','block');
                    var downloadBtn = $('<a>').attr('href', filePath).attr('download', imgAlt + '.doc').text('Download');
                    $('#modalBody').empty().append(img).append(downloadBtn);
                }
                $("#myModal").modal('show');
            }
        );
    }
</script>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <h1 class="text-center mb-4">View File(s)</h1>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                    <th>Filename</th>
                    <th>Key</th>
                    <th>FilePath</th>
                    <th>View</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $resultSet = getAllData();
                        while ($row = $resultSet->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['filename']; ?></td>
                                    <td><?php echo $row['filekey']; ?></td>
                                    <td><?php echo $row['filepath']; ?></td>
                                    <td><button type="button" class="btn btn-primary" onclick="getFileData(<?php echo $row['id']; ?>)">View</button></td>
                                </tr>
                            <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modalBody">
        
      </div>
    </div>
  </div>
</div>
<?php getFooter(); ?>