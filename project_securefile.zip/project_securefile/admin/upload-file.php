<?php
    include 'functions.php';
    getHeader();
    if(!checkAdminSession())
    {
        ?>
            <script>location.href='index.php';</script>
        <?php
    }
?>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <h1 class="text-center mb-4" style="margin-top:10%;">Upload File</h1>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form method="POST" action="" enctype="multipart/form-data">
                    <select class="form-control" name="fileenctype">
                        <option>Choose File Encrytion Type</option>
                        <option value="aes">AES</option>
                        <option value="rsa">RSA</option>
                        <option value="combined">Combined AES + RSA</option>
                        <option value="pfs">PFS</option>
                    </select>
                    <input type="file" name="file" class="form-control"><br>
                    <button type="submit" name="submit" class="btn btn-primary" style="margin:auto;display:block;">Upload</button>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</main>
<?php getFooter(); ?>

<?php
    if(isset($_POST['submit']))
    {
        $fileenctype = $_POST['fileenctype'];
        $file = $_FILES['file'];
        
        uploadFile($fileenctype,$file);
    }
?>