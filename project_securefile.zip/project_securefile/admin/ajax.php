<?php

    include 'functions.php';

    if(isset($_POST['fileid']))
    {
        $fileid = $_POST['fileid'];

        $responseArray = decryptFile($fileid);
        echo json_encode($responseArray);
    }

    if(isset($_POST['grant_user_id']) && isset($_POST['grant_file_id']))
    {
        $userID = $_POST['grant_user_id'];
        $fileID = $_POST['grant_file_id'];

        $result = grantAccess($userID,$fileID);
        echo $result;
    }

?>