<?php
    include 'functions.php';
    getHeader();
    if(!checkAdminSession())
    {
        ?>
            <script>location.href='index.php';</script>
        <?php
    }
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
    function grantAccess(user_id, file_id)
    {
        $.post(
            'ajax.php',
            'grant_user_id='+user_id+'&grant_file_id='+file_id,
            function(response)
            {
                console.log(response);
                if(response == '1')
                {
                    alert('Request has been granted successfully.');
                    location.reload();
                }
            }
        );
    }
</script>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <h1 class="text-center mb-4">Pending Request(s)</h1>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                    <th>UserID</th>
                    <th>FileID</th>
                    <th>FileName</th>
                    <th>File Ecryption Type</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $resultSet = getAllPendingRequests();
                        if(is_array($resultSet))
                        {
                            echo 'No Pending Request';
                        }
                        else{
                            while ($row = $resultSet->fetch_assoc()) {
                                ?>
                                    <tr>
                                        <td><?php echo $row['user_id']; ?></td>
                                        <td><?php echo $row['access_file_id']; ?></td>
                                        <td>
                                            <?php
                                                $result = getFileData($row['access_file_id']);
                                                $result = $result->fetch_assoc();
                                                echo $result['filename'];
                                            ?>
                                        </td>
                                        <td><?php echo $row['access_key_type']; ?></td>
                                        <td><button type="button" class="btn btn-primary" onclick="grantAccess(<?php echo $row['user_id']; ?>,<?php echo $row['access_file_id']; ?>)">Grant Access</button></td>
                                    </tr>
                                <?php
                            }
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<div class="modal" id="myModal">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="modalBody">
        
      </div>
    </div>
  </div>
</div>
<?php getFooter(); ?>