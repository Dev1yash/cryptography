<?php
    session_start();

    require '../vendor/autoload.php';

    use phpseclib3\Crypt\RSA;

    include_once '../config.php';

    function getHeader()
    {
        include 'header.php';
    }

    function getFooter()
    {
        include '../footer.php';
    }

    function login($email,$password)
    {
        $conn = OpenCon();
        $password = md5($password);
        if($stmt = $conn->prepare('SELECT * FROM admin WHERE email = ? AND password = ?'))
        {
            $stmt->bind_param('ss',$email,$password);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if ($resultSet->num_rows > 0)
                {
                    $result = $resultSet->fetch_assoc();
                    $_SESSION['admin_login'] = true;
                    $_SESSION['admin_id'] = $result['id'];
                    $_SESSION['admin_email'] = $result['email'];

                ?>
                        <script>location.href='dashboard.php';</script>
                <?php
                }
                else{
                    ?>
                        <script>
                            alert('Login details are incorrect');
                        </script>
                    <?php
                }
            }
        }
    }

    function uploadFile($fileenctype, $file)
    {
        if($fileenctype == 'aes')
        {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                die("Upload failed with error code " . $file['error']);
            }
            $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'txt', 'doc', 'docx');
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (!in_array($fileExtension, $allowedExtensions)) {
                die("Invalid file type. Allowed types: " . implode(',', $allowedExtensions));
            }
            $fileContent = file_get_contents($file['tmp_name']);
            $key = bin2hex(random_bytes(32));
            $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
            $encryptedContent = openssl_encrypt($fileContent, 'aes-256-cbc', $key, 0, $iv);
            $destination = '../assets/uploads/' . $file['name'] . '.enc';
            file_put_contents($destination, $iv . $encryptedContent);
            $conn = OpenCon();
            if($stmt = $conn->prepare('INSERT INTO metadata(filename,fileenctype,filekey,filepath) VALUES(?,?,?,?)'))
            {
                $stmt->bind_param('ssss',$file['name'],$fileenctype,$key,$destination);
                $stmt->execute();
                ?>
                    <script>
                        alert('File has been uploaded successfully.');
                        location.href='dashboard.php';
                    </script>
                <?php
            }
        }
        if ($fileenctype == 'rsa') {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                die("Upload failed with error code " . $file['error']);
            }
            $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'txt', 'doc', 'docx');
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (!in_array($fileExtension, $allowedExtensions)) {
                die("Invalid file type. Allowed types: " . implode(',', $allowedExtensions));
            }
            $private = RSA::createKey();
            $public = $private->getPublicKey();
            $ciphertext = $private->getPublicKey()->encrypt($file['name']);
            $ciphertext = md5($ciphertext);
            $fileContent = file_get_contents($file['tmp_name']);
            $destination = '../assets/uploads2/' . $file['name'];
            move_uploaded_file($file["tmp_name"], $destination);
            $conn = OpenCon();
            if($stmt = $conn->prepare('INSERT INTO metadata(filename, fileenctype, filekey, filepath) VALUES(?,?,?,?)'))
            {
                $stmt->bind_param('ssss',$file['name'],$fileenctype,$ciphertext,$destination);
                $stmt->execute();
                ?>
                    <script>
                        alert('File has been uploaded successfully.');
                        location.href='dashboard.php';
                    </script>
                <?php
            }
        }
        if($fileenctype == 'combined')
        {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                die("Upload failed with error code " . $file['error']);
            }
            $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'txt', 'doc', 'docx');
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (!in_array($fileExtension, $allowedExtensions)) {
                die("Invalid file type. Allowed types: " . implode(',', $allowedExtensions));
            }
            // aes
            $key = bin2hex(random_bytes(32));
            $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
            $ciphertext = openssl_encrypt($file['name'], 'aes-256-cbc', $key, 0, $iv);
            // rsa
            $private = RSA::createKey();
            $public = $private->getPublicKey();
            $ciphertext = $private->getPublicKey()->encrypt($ciphertext);
            $ciphertext = md5($ciphertext);
            $fileContent = file_get_contents($file['tmp_name']);
            $destination = '../assets/uploads2/' . $file['name'];
            move_uploaded_file($file["tmp_name"], $destination);
            $conn = OpenCon();
            if($stmt = $conn->prepare('INSERT INTO metadata(filename, fileenctype, filekey, filepath) VALUES(?,?,?,?)'))
            {
                $stmt->bind_param('ssss',$file['name'],$fileenctype,$ciphertext,$destination);
                $stmt->execute();
                ?>
                    <script>
                        alert('File has been uploaded successfully.');
                        location.href='dashboard.php';
                    </script>
                <?php
            }
        }
        if($fileenctype == 'pfs')
        {
            if ($file['error'] !== UPLOAD_ERR_OK) {
                die("Upload failed with error code " . $file['error']);
            }
            $allowedExtensions = array('jpg', 'jpeg', 'png', 'gif', 'txt', 'doc', 'docx');
            $fileExtension = pathinfo($file['name'], PATHINFO_EXTENSION);
            if (!in_array($fileExtension, $allowedExtensions)) {
                die("Invalid file type. Allowed types: " . implode(',', $allowedExtensions));
            }
            //pfs
            $prime = gmp_init("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE65381FFFFFFFFFFFFFFFF", 16);
            $generator = gmp_init("2", 10);
            $privateKey = gmp_random_range(2, gmp_sub($prime, 1));
            $publicKey = gmp_powm($generator, $privateKey, $prime);
            file_put_contents('public.pem', gmp_export($publicKey));
            file_put_contents('recipient-public.pem', gmp_export($publicKey));
            $recipientPublicKey = gmp_import(file_get_contents('recipient-public.pem'));
            $sharedSecret = gmp_powm($recipientPublicKey, $privateKey, $prime);
            $sharedSecretHex = gmp_strval($sharedSecret, 16);
            $fileContent = file_get_contents($file['tmp_name']);
            $key = hex2bin($sharedSecretHex);  
            $key = md5($key);
            $destination = '../assets/uploads2/' . $file['name'];
            move_uploaded_file($file["tmp_name"], $destination);
            $conn = OpenCon();
            if($stmt = $conn->prepare('INSERT INTO metadata(filename,fileenctype,filekey,filepath) VALUES(?,?,?,?)'))
            {
                $stmt->bind_param('ssss',$file['name'],$fileenctype,$key,$destination);
                $stmt->execute();
                ?>
                    <script>
                        alert('File has been uploaded successfully.');
                        location.href='dashboard.php';
                    </script>
                <?php
            }
        }
         
    }

    function getAllData()
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata'))
        {
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                return $resultSet;
            }
        }
    }

    function decryptFile($fileid)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata WHERE id = ?'))
        {
            $stmt->bind_param('s',$fileid);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if ($resultSet->num_rows > 0)
                {
                    $result = $resultSet->fetch_assoc();
                    if($result['fileenctype'] == 'aes')
                    {
                        $key = $result['filekey']; 
                        $encryptedContent = file_get_contents($result['filepath']);
                        $iv = substr($encryptedContent, 0, openssl_cipher_iv_length('aes-256-cbc'));
                        $encryptedContent = substr($encryptedContent, openssl_cipher_iv_length('aes-256-cbc'));
                        $fileContent = openssl_decrypt($encryptedContent, 'aes-256-cbc', $key, 0, $iv);
                        $savedFilePath = '../assets/uploads/'.$result['filename'];
                        file_put_contents($savedFilePath, $fileContent);
                        $fileType = $result['filename'];
                        $fileType = explode('.',$fileType);
                        $fileType = $fileType[1];

                        $resultArray = array('fileType' => $fileType, 'filePath' => $savedFilePath);
                        return $resultArray;
                    }
                    else{
                        $savedFilePath = '../assets/uploads2/'.$result['filename'];
                        $fileType = $result['filename'];
                        $fileType = explode('.',$fileType);
                        $fileType = $fileType[1];

                        $resultArray = array('fileType' => $fileType, 'filePath' => $savedFilePath);
                        return $resultArray;
                    }
                }
            }
        }
    }

    function getAllPendingRequests()
    {
        $conn = OpenCon();
        if($stmt=$conn->prepare('SELECT * FROM access_log WHERE access_granted_status = "P" '))
        {
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if($resultSet->num_rows > 0)
                {
                    return $resultSet;
                }
                else{
                    $resultSet = array(
                        "status" => "not_exist"
                    );
                    return $resultSet;
                }
            }
        }
    }

    function getFileData($fileID)
    {
        $conn = OpenCon();
        if($stmt=$conn->prepare('SELECT * FROM metadata WHERE id = ?'))
        {
            $stmt->bind_param('i',$fileID);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if($resultSet->num_rows>0)
                {
                    return $resultSet;
                }
            }
        }
    }

    function grantAccess($userID,$fileID)
    {
        $conn = OpenCon();
        if($stmt=$conn->prepare('UPDATE access_log SET access_granted_status = "G" WHERE user_id = ? AND access_file_id = ? '))
        {
            $stmt->bind_param('ii',$userID, $fileID);
            if($stmt->execute())
            {
                return '1';
            }
        }
    }

    function checkAdminSession()
    {
        if(isset($_SESSION['admin_login']))
        {
            return true;
        }
    }
?>