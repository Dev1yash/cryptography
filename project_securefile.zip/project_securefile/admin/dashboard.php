<?php
    include 'functions.php';
    getHeader();
    if(!checkAdminSession())
    {
        ?>
            <script>location.href='index.php';</script>
        <?php
    }
?>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <p class="lead">Welcome, <?php echo $_SESSION['admin_email']; ?></p>
        <div class="row">
            <div class="col-md-4">
                <div class="card" style="width:400px">
                    <img class="card-img-top" src="../assets/img/upload-file.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                        <h4 class="card-title text-center">Upload FIle</h4>
                        <a href="upload-file.php" class="btn btn-primary" style="margin: auto;display: block;">Go</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card" style="width:400px">
                    <img class="card-img-top" src="../assets/img/view-file.png" alt="Card image" style="width:100%">
                    <div class="card-body">
                        <h4 class="card-title text-center">View File</h4>
                        <a href="view-file.php" class="btn btn-primary" style="margin: auto;display: block;">Go</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card" style="width:400px">
                    <img class="card-img-top" src="../assets/img/view-request.jpg" alt="Card image" style="width:100%">
                    <div class="card-body">
                        <h4 class="card-title text-center">View Request</h4>
                        <a href="view-request.php" class="btn btn-primary" style="margin: auto;display: block;">Go</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php getFooter(); ?>