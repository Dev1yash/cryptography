<?php
/*$keyPair = openssl_pkey_new(array(
    "private_key_bits" => 2048,
    "private_key_type" => OPENSSL_KEYTYPE_RSA,
    'config' => 'C:\xampp\php\extras\openssl\openssl.cnf',
));

// Export the private key to a string
$privateKey = '';
openssl_pkey_export($keyPair, $privateKey);
var_dump($privateKey);*/

// Generate a new private (and public) key pair
$configArgs = array(
    'config' => 'C:\xampp\php\extras\openssl\openssl.cnf'
);
$privkey = openssl_pkey_new(array(
    "private_key_bits" => 2048,
    "private_key_type" => OPENSSL_KEYTYPE_RSA,
    'config' => 'C:\xampp\php\extras\openssl\openssl.cnf'
 ));
 var_dump($privkey);
?>
