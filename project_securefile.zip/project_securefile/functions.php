<?php
    session_start();

    include_once 'config.php';

    function getHeader()
    {
        include 'header.php';
    }

    function getFooter()
    {
        include 'footer.php';
    }

    function register($name,$email,$mobile,$address,$username,$password)
    {
        $conn = OpenCon();
        if ($stmt = $conn->prepare('INSERT INTO users(name,email,mobile,address,username,password) VALUES(?,?,?,?,?,?)'))
        {
            $password = md5($password);
            $stmt->bind_param('ssssss', $name,$email,$mobile,$address,$username,$password);
            if($stmt->execute())
            {
                ?>
                    <script>
                        alert('You have been registered successfully.');
                    </script>
                <?php
            }
            else{
                ?>
                    <script>
                        alert('Unable to register. Please try again later.');
                    </script>
                <?php
            }
        }
    }

    function login($email,$password)
    {
        $conn = OpenCon();
        $password = md5($password);
        if($stmt = $conn->prepare('SELECT * FROM users WHERE email = ? AND password = ?'))
        {
            $stmt->bind_param('ss',$email,$password);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if ($resultSet->num_rows > 0)
                {
                    $result = $resultSet->fetch_assoc();
                    $_SESSION['user_id'] = $result['id'];
                    $_SESSION['name'] = $result['username'];
                    $_SESSION['email'] = $result['email'];

                ?>
                        <script>location.href='dashboard.php';</script>
                <?php
                }
                else{
                    ?>
                        <script>
                            alert('Login details are incorrect');
                        </script>
                    <?php
                }
            }
        }
    }

    function getAllData()
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata'))
        {
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                return $resultSet;
            }
        }
    } 

    function getFileData($file_id)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata WHERE id = ?'))
        {
            $stmt->bind_param('i',$file_id);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                return $resultSet;
            }
        }
    }

    function checkRequestAccessStatus($user_id,$file_id)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM access_log WHERE user_id = ? AND access_file_id = ?'))
        {
            $stmt->bind_param('ii',$user_id,$file_id);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if($resultSet->num_rows > 0)
                {
                    return $resultSet;
                }
                else{
                    $resultSet = array(
                        "status" => "not_exist"
                    );
                    return $resultSet;
                }
            }
        }
    }

    function getFileEncType($fileID)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata WHERE id = ?'))
        {
            $stmt->bind_param('i',$fileID);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                $resultSet = $resultSet->fetch_assoc();
                return $resultSet['fileenctype'];
            }
        }
    }

    function insertFileRequest($user_id,$file_id)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM access_log WHERE user_id = ? AND access_file_id = ?'))
        {
            $stmt->bind_param('ii',$user_id,$file_id);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if($resultSet->num_rows > 0)
                {
                    return '1';
                }
                else{
                    if($stmt = $conn->prepare('INSERT INTO access_log(user_id, access_key_type, access_file_id, access_granted_status) VALUES(?,?,?,?)'))
                    {
                        $access_key_type = getFileEncType($file_id);
                        $access_granted_status = 'P';
                        $stmt->bind_param('isis',$user_id, $access_key_type, $file_id, $access_granted_status);
                        if($stmt->execute())
                        {
                            return '1';
                        }
                        else{
                            return '2';
                        }
                    }
                }
            }
        }
    }

    function decryptFile($fileid)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata WHERE id = ?'))
        {
            $stmt->bind_param('s',$fileid);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if ($resultSet->num_rows > 0)
                {
                    $result = $resultSet->fetch_assoc();
                    $key = $result['filekey']; 
                    $filePath = str_replace("../","",$result['filepath']);
                    $encryptedContent = file_get_contents($filePath);
                    $iv = substr($encryptedContent, 0, openssl_cipher_iv_length('aes-256-cbc'));
                    $encryptedContent = substr($encryptedContent, openssl_cipher_iv_length('aes-256-cbc'));
                    $fileContent = openssl_decrypt($encryptedContent, 'aes-256-cbc', $key, 0, $iv);
                    $savedFilePath = 'assets/uploads/'.$result['filename'];
                    file_put_contents($savedFilePath, $fileContent);
                    $fileType = $result['filename'];
                    $fileType = explode('.',$fileType);
                    $fileType = $fileType[1];

                    $resultArray = array('fileType' => $fileType, 'filePath' => $savedFilePath);
                    return $resultArray;
                }
            }
        }
    }

    function createDownloadLink($fileKey)
    {
        $conn = OpenCon();
        if($stmt = $conn->prepare('SELECT * FROM metadata WHERE filekey = ?'))
        {
            $stmt->bind_param('s',$fileKey);
            if($stmt->execute())
            {
                $resultSet = $stmt->get_result();
                if($resultSet->num_rows>0)
                {
                    $resultSet = $resultSet->fetch_assoc();
                    if($resultSet['fileenctype'] == 'aes')
                    {
                        $result = decryptFile($resultSet['id']);
                        $filepath = $result['filePath'];
                        $resultArray = array('filePath' => $filepath);
                        return $resultArray;
                    }
                    if($resultSet['fileenctype'] == 'rsa')
                    {
                        // copy file to uploads folder.
                        $sourcePath =  str_replace("../","",$resultSet['filepath']);
                        $destinationPath = 'assets/uploads/'.$resultSet['filename'];
                        copy($sourcePath, $destinationPath);
                        $resultArray = array('filePath' => $destinationPath);
                        return $resultArray;
                    }
                    if($resultSet['fileenctype'] == 'combined')
                    {
                        // copy file to uploads folder.
                        $sourcePath =  str_replace("../","",$resultSet['filepath']);
                        $destinationPath = 'assets/uploads/'.$resultSet['filename'];
                        copy($sourcePath, $destinationPath);
                        $resultArray = array('filePath' => $destinationPath);
                        return $resultArray;
                    }
                    if($resultSet['fileenctype'] == 'pfs')
                    {
                        // copy file to uploads folder.
                        $sourcePath =  str_replace("../","",$resultSet['filepath']);
                        $destinationPath = 'assets/uploads/'.$resultSet['filename'];
                        copy($sourcePath, $destinationPath);
                        $resultArray = array('filePath' => $destinationPath);
                        return $resultArray;
                    }
                }
            }
        }
    }

    function checkUserSession()
    {
        if(isset($_SESSION['user_id']))
        {
            return true;
        }
    }
?>