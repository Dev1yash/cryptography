<?php
    include 'functions.php';
    getHeader();
    if(checkUserSession())
    {
        ?>
            <script>location.href='dashboard.php'</script>
        <?php
    }
?>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <h1 class="text-center mb-4">Login</h1>
        <div class=row>
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <form action="" method="post">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="d-grid gap-2">
                        <button type="submit" name="submit" class="btn btn-primary">Login</button>
                    </div>
                </form>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>
</main>
<?php getFooter(); ?>
<?php
    if(isset($_POST['submit']))
    {
        $email = $_POST['email'];
        $password = $_POST['password'];

        login($email,$password);
    }
?>