        <footer class="bg-light py-4">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h5>About Us</h5>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer quis justo enim. Morbi mollis ipsum vel lectus facilisis porta. Donec accumsan leo sed lectus pretium, in sodales urna elementum. Fusce ut ex eget metus euismod bibendum.</p>
                    </div>
                    <div class="col-md-4">
                        <h5>Contact Us</h5>
                        <ul class="list-unstyled">
                            <li><i class="bi bi-geo-alt-fill me-2"></i>123 Main Street, New York, NY 10001</li>
                            <li><i class="bi bi-phone-fill me-2"></i>1-800-123-4567</li>
                            <li><i class="bi bi-envelope-fill me-2"></i>info@example.com</li>
                        </ul>
                    </div>
                    <div class="col-md-4">
                        <h5>Follow Us</h5>
                        <ul class="list-inline">
                            <li class="list-inline-item"><a href="#"><i class="bi bi-facebook"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="bi bi-twitter"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="bi bi-instagram"></i></a></li>
                            <li class="list-inline-item"><a href="#"><i class="bi bi-linkedin"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="text-center p-3 bg-secondary text-white" style="margin-bottom: -24px;">
                <p>&copy; 2023 My Website. All rights reserved.</p>
            </div>
        </footer>
    </body>
</html>