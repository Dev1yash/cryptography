<?php

include 'config.php';
// Set the file path
$file_path = $_GET['file'];

// Set the file name
$file_name = str_replace("assets/uploads/","",$file_path);

// Set the headers for the file download
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $file_name . '"');
header('Content-Transfer-Encoding: binary');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($file_path));

// Read the file and output it to the browser
readfile($file_path);
// Delete the file
unlink($file_path);

$check_file_path = str_replace("assets/uploads/","../assets/uploads2/",$file_path);
$conn = Opencon();
if($stmt=$conn->prepare('SELECT * FROM metadata WHERE filepath = ?'))
{
    $stmt->bind_param('s',$check_file_path);
    if($stmt->execute())
    {
        $resultSet = $stmt->get_result();
        if($resultSet->num_rows>0)
        {
            $resultSet = $resultSet->fetch_assoc();
            if($resultSet['fileenctype'] == 'pfs')
            {
                $fileid = $resultSet['id'];
                if($stmt=$conn->prepare('DELETE FROM metadata WHERE id = ?'))
                {
                    $stmt->bind_param('i',$fileid);
                    if($stmt->execute())
                    {
                        if($stmt=$conn->prepare('DELETE FROM access_log WHERE access_file_id = ?'))
                        {
                            $stmt->bind_param('i',$fileid);
                            $stmt->execute();
                        }
                    }
                }
            }
        }
    }
}

