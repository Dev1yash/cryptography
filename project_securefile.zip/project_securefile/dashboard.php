<?php
    include 'functions.php';
    getHeader();
    if(!checkUserSession())
    {
        ?>
            <script>location.href='index.php';</script>
        <?php
    }
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script>
    function requestAccess(user_id, file_id)
    {
        $.post(
            'ajax.php',
            'user_id='+user_id+'&file_id='+file_id,
            function(response)
            {
                console.log(response);
                if(response == '1')
                {
                    location.reload();
                }
                else{
                    alert('Error in creating request. Please try again later.');
                }
            }
        );
    }
    function downloadModal()
    {
        $("#fileModal").modal('show');
    }
</script>
<main class="flex-grow-1">
    <!-- Main content here -->
    <div class="container py-5">
        <?php echo $_SESSION['email']; ?>
        <div class="table-responsive">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                    <th>FileID</th>
                    <th>FileName</th>
                    <th>View</th>
                    <th>Download</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $resultSet = getAllData();
                        while ($row = $resultSet->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo $row['filename']; ?></td>
                                    <td>
                                        <?php 
                                            $fileAccessStatus = checkRequestAccessStatus($_SESSION['user_id'],$row['id']) ;
                                            if(is_array($fileAccessStatus))
                                            {
                                                ?>
                                                    <button class="btn btn-primary" onclick="requestAccess(<?php echo $_SESSION['user_id'] ?>,<?php echo $row['id'] ?>)">Request Access</button>
                                                <?php
                                            }
                                            else{
                                                $fileAccessStatus = $fileAccessStatus->fetch_assoc();
                                                if($fileAccessStatus['access_granted_status'] == 'G')
                                                {
                                                    echo $row['filekey'];
                                                }
                                                if($fileAccessStatus['access_granted_status'] == 'P')
                                                {
                                                    echo 'Your request is Pending.';
                                                }
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                            $fileAccessStatus = checkRequestAccessStatus($_SESSION['user_id'],$row['id']) ;
                                            if(is_array($fileAccessStatus))
                                            {
                                                echo 'Request for access to download';
                                            }
                                            else{
                                                $fileAccessStatus = $fileAccessStatus->fetch_assoc();
                                                if($fileAccessStatus['access_granted_status'] == 'G')
                                                {
                                                    ?>
                                                        <button class="btn btn-primary" onclick="downloadModal()">Download</button>
                                                    <?php
                                                }
                                                if($fileAccessStatus['access_granted_status'] == 'P')
                                                {
                                                    echo 'Your request is Pending.';
                                                }
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php
                        }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</main>
<!-- File Download Modal -->
<div class="modal" id="fileModal">
  <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <!-- Modal Header -->
      <div class="modal-header">
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <!-- Modal body -->
      <div class="modal-body" id="fileModalContent">
        <input class="form-control" type="text" placeholder="Enter File Key" id="filesbtkey"><br>
        <button type="button" class="btn btn-primary" style="margin:auto;display:block;" name="submit" onclick="sbtmodal()">Submit</button>
      </div>
    </div>
  </div>
</div>
<script>
    function sbtmodal()
    {
        filesbtkey = $('#filesbtkey').val();
        $.post(
            'ajax.php',
            'filesbtkey='+filesbtkey,
            function(response)
            {
                console.log(response);
                location.href='download.php?file='+response;
            }
        );
    }
</script>
<?php getFooter(); ?>